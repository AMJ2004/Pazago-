# RAG Document Processing & Chat System

## Overview

This is a full-stack RAG (Retrieval-Augmented Generation) application that allows users to upload documents and chat with an AI assistant that can reference the content of those documents. The system processes documents by extracting text, chunking content, generating embeddings, and storing them in a vector database for semantic search during chat interactions.

The application is built with a React frontend using shadcn/ui components, an Express.js backend, PostgreSQL with vector extensions for document storage, and integrates with OpenAI's API for embeddings and chat completion.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite for development/build tooling
- **UI Library**: shadcn/ui components built on Radix UI primitives with Tailwind CSS for styling
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **File Uploads**: react-dropzone for drag-and-drop file upload functionality
- **Build Tool**: Vite with custom configuration for development and production builds

### Backend Architecture  
- **Framework**: Express.js with TypeScript running on Node.js
- **Database ORM**: Drizzle ORM for type-safe database operations with PostgreSQL
- **File Processing**: 
  - pdf-parse for PDF text extraction
  - multer for handling multipart file uploads
  - File system operations for temporary file storage during processing
- **API Design**: RESTful endpoints for document management and chat functionality
- **Error Handling**: Centralized error handling middleware with structured error responses

### Data Storage Solutions
- **Primary Database**: PostgreSQL with vector extension support (pgvector) for storing:
  - User accounts and authentication data
  - Document metadata (filename, size, processing status, etc.)
  - Document chunks with vector embeddings for semantic search  
  - Chat conversations and message history
  - Agent memory for contextual awareness
- **Vector Storage**: 1536-dimensional embeddings stored as PostgreSQL vector type
- **File Storage**: Local filesystem for temporary upload storage during processing
- **Session Storage**: PostgreSQL-backed session storage using connect-pg-simple

### Authentication and Authorization  
- **Demo Mode**: Currently configured with a hardcoded demo user for development
- **Session Management**: Express sessions with PostgreSQL storage
- **User Model**: Simple username/password authentication (production would require proper password hashing)
- **Authorization**: User-scoped data access ensuring users only see their own documents and conversations

### Document Processing Pipeline
1. **Upload**: Files received via multipart upload with validation for PDF, TXT, and DOCX formats
2. **Text Extraction**: Content extracted based on file type (PDF parsing, plain text reading)
3. **Chunking**: Text split into overlapping chunks (1000 characters with 200 character overlap)
4. **Embedding Generation**: Each chunk processed through OpenAI's text-embedding-ada-002 model
5. **Storage**: Chunks and embeddings stored in PostgreSQL vector tables
6. **Status Tracking**: Document processing status tracked through state machine (uploading → processing → ready/error)

### Chat System Architecture
- **Context Retrieval**: Semantic search over document embeddings to find relevant chunks
- **Prompt Engineering**: System prompts that incorporate retrieved document context
- **Conversation Management**: Persistent chat history with conversation threading
- **Response Generation**: OpenAI GPT integration for generating contextually-aware responses
- **Memory System**: Agent memory storage for maintaining context across conversations

## External Dependencies

### Core Services
- **OpenAI API**: 
  - text-embedding-ada-002 for document chunk embeddings
  - GPT models for chat completion (configured for latest available model)
  - API key required via environment variable
- **PostgreSQL Database**: 
  - Neon serverless PostgreSQL or compatible PostgreSQL instance
  - Requires vector extension (pgvector) for embedding storage
  - Connection string required via DATABASE_URL environment variable

### Development and Deployment
- **Replit Integration**: 
  - @replit/vite-plugin-runtime-error-modal for development error overlay
  - @replit/vite-plugin-cartographer for dependency mapping
  - @replit/vite-plugin-dev-banner for development environment indicators
- **Database Migrations**: Drizzle Kit for schema migrations and database setup
- **Build Tools**: esbuild for server-side bundling, Vite for client-side bundling

### UI and Styling Dependencies  
- **Component Library**: Extensive shadcn/ui component collection including:
  - Form controls (inputs, selects, checkboxes, etc.)
  - Layout components (cards, dialogs, sheets, etc.)  
  - Feedback components (toasts, progress bars, alerts, etc.)
- **Icons**: Lucide React for consistent iconography
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Typography**: Google Fonts integration (Inter, Architects Daughter, DM Sans, etc.)

### File Processing Libraries
- **PDF Processing**: pdf-parse for extracting text content from PDF files
- **File Uploads**: multer with file type and size validation
- **Date Utilities**: date-fns for date formatting and manipulation
- **Validation**: Zod with drizzle-zod for runtime schema validation