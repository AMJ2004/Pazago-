import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import path from "path";
import { promises as fs } from "fs";
import { storage } from "./storage";
import { documentService } from "./services/document";
import { openaiService } from "./services/openai";
import { insertDocumentSchema, chatRequestSchema } from "@shared/schema";
import { z } from "zod";

// Configure multer for file uploads
const upload = multer({
  dest: "uploads/",
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedMimes = [
      "application/pdf",
      "text/plain",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    ];
    
    if (allowedMimes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error("Invalid file type. Only PDF, TXT, and DOCX files are allowed."));
    }
  },
});

// Temporary user ID for demo (in production, this would come from authentication)
let DEMO_USER_ID: string;

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize demo user
  try {
    let user = await storage.getUserByUsername("demo");
    if (!user) {
      user = await storage.createUser({
        username: "demo",
        password: "demo123", // In production, this should be properly hashed
      });
    }
    DEMO_USER_ID = user.id;
    console.log("Demo user initialized with ID:", DEMO_USER_ID);
  } catch (error) {
    console.error("Failed to initialize demo user:", error);
    throw error; // Don't continue if we can't create the demo user
  }

  // Document upload endpoint
  app.post("/api/documents/upload", upload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      const document = await storage.createDocument({
        userId: DEMO_USER_ID,
        filename: req.file.filename,
        originalName: req.file.originalname,
        mimeType: req.file.mimetype,
        size: req.file.size,
      });

      // Process document asynchronously
      documentService.processDocument(document.id, req.file.path).catch((error) => {
        console.error(`Background processing failed for document ${document.id}:`, error);
        // Update document status to error if processing fails
        storage.updateDocumentStatus(document.id, "error", error.message).catch(dbError => {
          console.error(`Failed to update document status to error:`, dbError);
        });
      });

      res.json({
        id: document.id,
        filename: document.originalName,
        status: document.status,
        size: document.size,
      });
    } catch (error) {
      console.error("Upload error:", error);
      res.status(500).json({ error: "Failed to upload document" });
    }
  });

  // Get user documents
  app.get("/api/documents", async (req, res) => {
    try {
      const documents = await storage.getUserDocuments(DEMO_USER_ID);
      
      // Get chunk count for each document
      const documentsWithStats = await Promise.all(
        documents.map(async (doc) => {
          const chunks = await storage.getDocumentChunks(doc.id);
          return {
            ...doc,
            embeddingCount: chunks.length,
          };
        })
      );
      
      res.json(documentsWithStats);
    } catch (error) {
      console.error("Failed to get documents:", error);
      res.status(500).json({ error: "Failed to retrieve documents" });
    }
  });

  // Get document details
  app.get("/api/documents/:id", async (req, res) => {
    try {
      const document = await storage.getDocument(req.params.id);
      if (!document) {
        return res.status(404).json({ error: "Document not found" });
      }

      if (document.userId !== DEMO_USER_ID) {
        return res.status(403).json({ error: "Access denied" });
      }

      const chunks = await storage.getDocumentChunks(document.id);
      res.json({
        ...document,
        embeddingCount: chunks.length,
      });
    } catch (error) {
      console.error("Failed to get document:", error);
      res.status(500).json({ error: "Failed to retrieve document" });
    }
  });

  // Delete document
  app.delete("/api/documents/:id", async (req, res) => {
    try {
      const document = await storage.getDocument(req.params.id);
      if (!document) {
        return res.status(404).json({ error: "Document not found" });
      }

      if (document.userId !== DEMO_USER_ID) {
        return res.status(403).json({ error: "Access denied" });
      }

      // Delete file from filesystem
      try {
        await fs.unlink(path.join("uploads", document.filename));
      } catch (error) {
        console.log("File not found on filesystem, continuing with database cleanup");
      }

      // Note: Document chunks will be automatically deleted due to CASCADE foreign key
      // In a real implementation, you'd need a proper delete method
      res.json({ success: true });
    } catch (error) {
      console.error("Failed to delete document:", error);
      res.status(500).json({ error: "Failed to delete document" });
    }
  });

  // Chat endpoint
  app.post("/api/chat", async (req, res) => {
    try {
      const { message, conversationId } = chatRequestSchema.parse(req.body);

      // Create or get conversation
      let conversation;
      if (conversationId) {
        conversation = await storage.getConversation(conversationId);
        if (!conversation) {
          return res.status(404).json({ error: "Conversation not found" });
        }
      } else {
        conversation = await storage.createConversation({
          userId: DEMO_USER_ID,
          title: message.slice(0, 50) + (message.length > 50 ? "..." : ""),
        });
      }

      // Store user message
      await storage.createMessage({
        conversationId: conversation.id,
        role: "user",
        content: message,
      });

      // Search for relevant document context
      const searchResults = await documentService.searchDocuments(message, DEMO_USER_ID);
      const context = searchResults.chunks
        .map((chunk, index) => `Context ${index + 1}: ${chunk.content}`)
        .join("\n\n");

      // Get conversation history
      const messages = await storage.getConversationMessages(conversation.id);
      const conversationHistory = messages
        .filter(m => m.role !== "system")
        .slice(-10) // Last 10 messages for context
        .map(m => ({ role: m.role as 'user' | 'assistant', content: m.content }));

      // Generate AI response
      const aiResponse = await openaiService.generateChatResponse(
        conversationHistory,
        context.length > 0 ? context : undefined
      );

      // Store AI response
      const aiMessage = await storage.createMessage({
        conversationId: conversation.id,
        role: "assistant",
        content: aiResponse.content,
        metadata: JSON.stringify({
          tokenUsage: aiResponse.tokenUsage,
          documentsUsed: searchResults.documents.map(d => ({ id: d.id, name: d.originalName })),
        }),
      });

      res.json({
        message: aiMessage,
        conversationId: conversation.id,
        context: searchResults.documents.length > 0 ? {
          documentsUsed: searchResults.documents.map(d => ({
            id: d.id,
            name: d.originalName,
          })),
          chunksUsed: searchResults.chunks.length,
        } : undefined,
      });

    } catch (error) {
      console.error("Chat error:", error);
      res.status(500).json({ error: "Failed to process chat message" });
    }
  });

  // Get conversations
  app.get("/api/conversations", async (req, res) => {
    try {
      const conversations = await storage.getUserConversations(DEMO_USER_ID);
      res.json(conversations);
    } catch (error) {
      console.error("Failed to get conversations:", error);
      res.status(500).json({ error: "Failed to retrieve conversations" });
    }
  });

  // Get conversation messages
  app.get("/api/conversations/:id/messages", async (req, res) => {
    try {
      const conversation = await storage.getConversation(req.params.id);
      if (!conversation) {
        return res.status(404).json({ error: "Conversation not found" });
      }

      if (conversation.userId !== DEMO_USER_ID) {
        return res.status(403).json({ error: "Access denied" });
      }

      const messages = await storage.getConversationMessages(req.params.id);
      res.json(messages);
    } catch (error) {
      console.error("Failed to get messages:", error);
      res.status(500).json({ error: "Failed to retrieve messages" });
    }
  });

  // Search documents
  app.get("/api/search", async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ error: "Query parameter 'q' is required" });
      }

      const limit = parseInt(req.query.limit as string) || 5;
      const results = await documentService.searchDocuments(query, DEMO_USER_ID, limit);
      
      res.json(results);
    } catch (error) {
      console.error("Search error:", error);
      res.status(500).json({ error: "Failed to search documents" });
    }
  });

  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({ 
      status: "healthy", 
      timestamp: new Date().toISOString(),
      openai: !!process.env.OPENAI_API_KEY,
      database: true, // Will fail at startup if DB is not available
    });
  });

  const httpServer = createServer(app);
  return httpServer;
}
