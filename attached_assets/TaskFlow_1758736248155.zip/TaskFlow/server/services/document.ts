import { createReadStream, promises as fs } from "fs";
import path from "path";
import pdfParse from "pdf-parse";
import { openaiService } from "./openai";
import { storage } from "../storage";
import type { Document } from "@shared/schema";

export class DocumentService {
  private chunkSize = 1000; // characters per chunk
  private chunkOverlap = 200; // overlap between chunks

  async processDocument(documentId: string, filePath: string): Promise<void> {
    try {
      console.log(`Starting to process document ${documentId}`);
      
      const document = await storage.getDocument(documentId);
      if (!document) {
        throw new Error(`Document ${documentId} not found`);
      }

      await storage.updateDocumentStatus(documentId, "processing");

      // Extract text based on file type
      let textContent = "";
      let pageCount = 0;

      if (document.mimeType === "application/pdf") {
        const result = await this.extractTextFromPDF(filePath);
        textContent = result.text;
        pageCount = result.pageCount;
      } else if (document.mimeType === "text/plain") {
        textContent = await fs.readFile(filePath, "utf-8");
        pageCount = 1;
      } else {
        throw new Error(`Unsupported file type: ${document.mimeType}`);
      }

      // Update document with extracted content
      await storage.updateDocumentContent(documentId, textContent, pageCount);

      // Create chunks
      const chunks = this.createTextChunks(textContent);
      
      // Process chunks and generate embeddings
      for (let i = 0; i < chunks.length; i++) {
        const chunk = chunks[i];
        console.log(`Processing chunk ${i + 1}/${chunks.length} for document ${documentId}`);
        
        try {
          // Try to generate embeddings, but continue without them if it fails
          let embedding: number[] | undefined;
          let tokenCount: number | undefined;
          
          try {
            const embeddingResult = await openaiService.generateEmbedding(chunk);
            embedding = embeddingResult.embedding;
            tokenCount = embeddingResult.tokenCount;
          } catch (embeddingError) {
            console.warn(`Failed to generate embedding for chunk ${i} of document ${documentId}, continuing without embedding:`, embeddingError);
            // Continue without embedding - document will still be searchable by text
          }
          
          await storage.createDocumentChunk({
            documentId,
            content: chunk,
            chunkIndex: i,
            embedding,
            tokenCount,
          });
        } catch (error) {
          console.error(`Failed to process chunk ${i} for document ${documentId}:`, error);
          // Continue with other chunks even if one fails
        }
      }

      await storage.updateDocumentStatus(documentId, "ready");
      console.log(`Successfully processed document ${documentId}`);
      
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      console.error(`Failed to process document ${documentId}:`, error);
      await storage.updateDocumentStatus(documentId, "error", errorMessage);
      throw error;
    }
  }

  private async extractTextFromPDF(filePath: string): Promise<{ text: string; pageCount: number }> {
    try {
      const dataBuffer = await fs.readFile(filePath);
      const pdfData = await pdfParse(dataBuffer);
      
      return {
        text: pdfData.text,
        pageCount: pdfData.numpages,
      };
    } catch (error) {
      throw new Error(`Failed to extract text from PDF: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  private createTextChunks(text: string): string[] {
    const chunks: string[] = [];
    const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
    
    let currentChunk = "";
    
    for (const sentence of sentences) {
      const trimmedSentence = sentence.trim() + ".";
      
      if (currentChunk.length + trimmedSentence.length <= this.chunkSize) {
        currentChunk += " " + trimmedSentence;
      } else {
        if (currentChunk.length > 0) {
          chunks.push(currentChunk.trim());
          
          // Add overlap
          const words = currentChunk.split(" ");
          const overlapWords = words.slice(-Math.floor(this.chunkOverlap / 6)); // Approximate words for overlap
          currentChunk = overlapWords.join(" ") + " " + trimmedSentence;
        } else {
          currentChunk = trimmedSentence;
        }
      }
    }
    
    if (currentChunk.length > 0) {
      chunks.push(currentChunk.trim());
    }
    
    return chunks.filter(chunk => chunk.length > 50); // Filter out very short chunks
  }

  async searchDocuments(query: string, userId: string, limit = 5): Promise<{ chunks: any[]; documents: Document[] }> {
    try {
      // Generate embedding for the query
      const queryEmbedding = await openaiService.generateEmbedding(query);
      
      // Search for similar chunks
      const similarChunks = await storage.searchSimilarChunks(queryEmbedding.embedding, limit);
      
      // Get unique documents
      const documentIds = Array.from(new Set(similarChunks.map(chunk => chunk.documentId)));
      const documents: Document[] = [];
      
      for (const docId of documentIds) {
        const doc = await storage.getDocument(docId);
        if (doc && doc.userId === userId) {
          documents.push(doc);
        }
      }
      
      return {
        chunks: similarChunks,
        documents,
      };
    } catch (error) {
      throw new Error(`Failed to search documents: ${error instanceof Error ? error.message : String(error)}`);
    }
  }
}

export const documentService = new DocumentService();
