import OpenAI from "openai";

// Validate API key on startup
const apiKey = process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "";
if (!apiKey) {
  console.warn("OPENAI_API_KEY not found in environment variables. Document embedding and chat will not work.");
}

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: apiKey
});

export interface EmbeddingResult {
  embedding: number[];
  tokenCount: number;
}

export interface ChatResponse {
  content: string;
  finishReason: string;
  tokenUsage: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
  };
}

export class OpenAIService {
  async generateEmbedding(text: string): Promise<EmbeddingResult> {
    try {
      const response = await openai.embeddings.create({
        model: "text-embedding-ada-002",
        input: text,
      });

      return {
        embedding: response.data[0].embedding,
        tokenCount: response.usage.total_tokens,
      };
    } catch (error) {
      throw new Error(`Failed to generate embedding: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  async generateChatResponse(
    messages: Array<{ role: 'system' | 'user' | 'assistant'; content: string }>,
    context?: string
  ): Promise<ChatResponse> {
    try {
      const systemMessage = {
        role: 'system' as const,
        content: `You are a helpful AI assistant with access to uploaded documents. ${
          context ? `Here is relevant context from the documents:\n\n${context}` : ''
        }`
      };

      const response = await openai.chat.completions.create({
        model: "gpt-5",
        messages: [systemMessage, ...messages],
        max_completion_tokens: 2000,
      });

      const choice = response.choices[0];
      return {
        content: choice.message.content || '',
        finishReason: choice.finish_reason || 'stop',
        tokenUsage: {
          promptTokens: response.usage?.prompt_tokens || 0,
          completionTokens: response.usage?.completion_tokens || 0,
          totalTokens: response.usage?.total_tokens || 0,
        },
      };
    } catch (error) {
      throw new Error(`Failed to generate chat response: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  async summarizeText(text: string): Promise<string> {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-5",
        messages: [
          {
            role: "system",
            content: "You are a document summarization expert. Provide concise, accurate summaries that capture key points and main ideas."
          },
          {
            role: "user",
            content: `Please summarize the following text:\n\n${text}`
          }
        ],
        max_completion_tokens: 500,
      });

      return response.choices[0].message.content || '';
    } catch (error) {
      throw new Error(`Failed to summarize text: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  async extractKeywords(text: string): Promise<string[]> {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-5",
        messages: [
          {
            role: "system",
            content: "Extract the most important keywords and phrases from the given text. Return them as a JSON array of strings."
          },
          {
            role: "user",
            content: text
          }
        ],
        response_format: { type: "json_object" },
        max_completion_tokens: 200,
      });

      const result = JSON.parse(response.choices[0].message.content || '{"keywords": []}');
      return result.keywords || [];
    } catch (error) {
      throw new Error(`Failed to extract keywords: ${error instanceof Error ? error.message : String(error)}`);
    }
  }
}

export const openaiService = new OpenAIService();
