import { 
  users, documents, documentChunks, conversations, messages, agentMemory,
  type User, type InsertUser, type Document, type InsertDocument,
  type Conversation, type InsertConversation, type Message, type InsertMessage,
  type DocumentChunk, type AgentMemory
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Document methods
  createDocument(document: InsertDocument): Promise<Document>;
  getDocument(id: string): Promise<Document | undefined>;
  getUserDocuments(userId: string): Promise<Document[]>;
  updateDocumentStatus(id: string, status: Document['status'], error?: string): Promise<void>;
  updateDocumentContent(id: string, content: string, pageCount: number): Promise<void>;

  // Document chunk methods
  createDocumentChunk(chunk: {
    documentId: string;
    content: string;
    chunkIndex: number;
    embedding?: number[];
    tokenCount?: number;
  }): Promise<DocumentChunk>;
  getDocumentChunks(documentId: string): Promise<DocumentChunk[]>;
  searchSimilarChunks(embedding: number[], limit?: number, threshold?: number): Promise<DocumentChunk[]>;

  // Conversation methods
  createConversation(conversation: InsertConversation): Promise<Conversation>;
  getConversation(id: string): Promise<Conversation | undefined>;
  getUserConversations(userId: string): Promise<Conversation[]>;

  // Message methods
  createMessage(message: InsertMessage): Promise<Message>;
  getConversationMessages(conversationId: string): Promise<Message[]>;

  // Agent memory methods
  createAgentMemory(memory: {
    userId: string;
    conversationId?: string;
    memoryType: AgentMemory['memoryType'];
    content: string;
    importance?: number;
    embedding?: number[];
  }): Promise<AgentMemory>;
  getUserMemories(userId: string, limit?: number): Promise<AgentMemory[]>;
  searchSimilarMemories(embedding: number[], userId: string, limit?: number): Promise<AgentMemory[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async createDocument(document: InsertDocument): Promise<Document> {
    const [doc] = await db
      .insert(documents)
      .values(document)
      .returning();
    return doc;
  }

  async getDocument(id: string): Promise<Document | undefined> {
    const [doc] = await db.select().from(documents).where(eq(documents.id, id));
    return doc || undefined;
  }

  async getUserDocuments(userId: string): Promise<Document[]> {
    return await db
      .select()
      .from(documents)
      .where(eq(documents.userId, userId))
      .orderBy(desc(documents.createdAt));
  }

  async updateDocumentStatus(id: string, status: Document['status'], error?: string): Promise<void> {
    await db
      .update(documents)
      .set({ 
        status, 
        processingError: error,
        updatedAt: new Date()
      })
      .where(eq(documents.id, id));
  }

  async updateDocumentContent(id: string, content: string, pageCount: number): Promise<void> {
    await db
      .update(documents)
      .set({ 
        textContent: content, 
        pageCount,
        updatedAt: new Date()
      })
      .where(eq(documents.id, id));
  }

  async createDocumentChunk(chunk: {
    documentId: string;
    content: string;
    chunkIndex: number;
    embedding?: number[];
    tokenCount?: number;
  }): Promise<DocumentChunk> {
    const [docChunk] = await db
      .insert(documentChunks)
      .values({
        ...chunk,
        embedding: chunk.embedding ? JSON.stringify(chunk.embedding) as any : undefined
      })
      .returning();
    return docChunk;
  }

  async getDocumentChunks(documentId: string): Promise<DocumentChunk[]> {
    return await db
      .select()
      .from(documentChunks)
      .where(eq(documentChunks.documentId, documentId))
      .orderBy(documentChunks.chunkIndex);
  }

  async searchSimilarChunks(embedding: number[], limit = 5, threshold = 0.7): Promise<DocumentChunk[]> {
    const embeddingVector = JSON.stringify(embedding);
    return await db
      .select()
      .from(documentChunks)
      .where(sql`${documentChunks.embedding} <-> ${embeddingVector}::vector < ${threshold}`)
      .orderBy(sql`${documentChunks.embedding} <-> ${embeddingVector}::vector`)
      .limit(limit);
  }

  async createConversation(conversation: InsertConversation): Promise<Conversation> {
    const [conv] = await db
      .insert(conversations)
      .values(conversation)
      .returning();
    return conv;
  }

  async getConversation(id: string): Promise<Conversation | undefined> {
    const [conv] = await db.select().from(conversations).where(eq(conversations.id, id));
    return conv || undefined;
  }

  async getUserConversations(userId: string): Promise<Conversation[]> {
    return await db
      .select()
      .from(conversations)
      .where(eq(conversations.userId, userId))
      .orderBy(desc(conversations.updatedAt));
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const [msg] = await db
      .insert(messages)
      .values(message)
      .returning();
    return msg;
  }

  async getConversationMessages(conversationId: string): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, conversationId))
      .orderBy(messages.createdAt);
  }

  async createAgentMemory(memory: {
    userId: string;
    conversationId?: string;
    memoryType: AgentMemory['memoryType'];
    content: string;
    importance?: number;
    embedding?: number[];
  }): Promise<AgentMemory> {
    const [mem] = await db
      .insert(agentMemory)
      .values({
        ...memory,
        embedding: memory.embedding ? JSON.stringify(memory.embedding) as any : undefined
      })
      .returning();
    return mem;
  }

  async getUserMemories(userId: string, limit = 50): Promise<AgentMemory[]> {
    return await db
      .select()
      .from(agentMemory)
      .where(eq(agentMemory.userId, userId))
      .orderBy(desc(agentMemory.importance), desc(agentMemory.lastAccessedAt))
      .limit(limit);
  }

  async searchSimilarMemories(embedding: number[], userId: string, limit = 5): Promise<AgentMemory[]> {
    const embeddingVector = JSON.stringify(embedding);
    return await db
      .select()
      .from(agentMemory)
      .where(and(
        eq(agentMemory.userId, userId),
        sql`${agentMemory.embedding} <-> ${embeddingVector}::vector < 0.8`
      ))
      .orderBy(sql`${agentMemory.embedding} <-> ${embeddingVector}::vector`)
      .limit(limit);
  }
}

export const storage = new DatabaseStorage();
