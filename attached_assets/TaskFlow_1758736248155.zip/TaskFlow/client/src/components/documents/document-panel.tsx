import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { FileText, MoreHorizontal, Trash2, UploadCloud } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";
import { documentsApi, type Document } from "@/lib/api";

interface DocumentPanelProps {
  activeTab: "documents" | "context" | "memory";
  onTabChange: (tab: "documents" | "context" | "memory") => void;
  documents: Document[];
}

export function DocumentPanel({ activeTab, onTabChange, documents }: DocumentPanelProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const deleteDocumentMutation = useMutation({
    mutationFn: documentsApi.deleteDocument,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/documents"] });
      toast({
        title: "Document deleted",
        description: "The document has been removed successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete document",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 B";
    const k = 1024;
    const sizes = ["B", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
  };

  const getStatusColor = (status: Document["status"]) => {
    switch (status) {
      case "ready":
        return "bg-green-500";
      case "processing":
        return "bg-yellow-500 animate-pulse";
      case "error":
        return "bg-red-500";
      default:
        return "bg-gray-500";
    }
  };

  const getStatusText = (status: Document["status"]) => {
    switch (status) {
      case "ready":
        return "Ready";
      case "processing":
        return "Processing...";
      case "error":
        return "Error";
      default:
        return "Unknown";
    }
  };

  const totalDocuments = documents.length;
  const totalEmbeddings = documents.reduce((acc, doc) => acc + doc.embeddingCount, 0);
  const totalSize = documents.reduce((acc, doc) => acc + doc.size, 0);
  const storageLimit = 300 * 1024 * 1024; // 300MB limit
  const storagePercentage = Math.min((totalSize / storageLimit) * 100, 100);

  return (
    <div className="w-80 border-l border-border bg-card">
      {/* Tabs */}
      <div className="flex border-b border-border">
        <button
          onClick={() => onTabChange("documents")}
          className={`flex-1 px-4 py-3 text-sm font-medium transition-colors ${
            activeTab === "documents"
              ? "bg-accent text-accent-foreground border-b-2 border-primary"
              : "text-muted-foreground hover:text-foreground"
          }`}
          data-testid="tab-documents"
        >
          Documents
        </button>
        <button
          onClick={() => onTabChange("context")}
          className={`flex-1 px-4 py-3 text-sm font-medium transition-colors ${
            activeTab === "context"
              ? "bg-accent text-accent-foreground border-b-2 border-primary"
              : "text-muted-foreground hover:text-foreground"
          }`}
          data-testid="tab-context"
        >
          Context
        </button>
        <button
          onClick={() => onTabChange("memory")}
          className={`flex-1 px-4 py-3 text-sm font-medium transition-colors ${
            activeTab === "memory"
              ? "bg-accent text-accent-foreground border-b-2 border-primary"
              : "text-muted-foreground hover:text-foreground"
          }`}
          data-testid="tab-memory"
        >
          Memory
        </button>
      </div>

      {/* Tab Content */}
      <div className="p-4 space-y-4 h-full overflow-y-auto">
        {activeTab === "documents" && (
          <>
            {/* Upload Area */}
            <div className="border-2 border-dashed border-border rounded-lg p-6 text-center hover:border-primary/50 transition-colors">
              <UploadCloud className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
              <p className="text-sm text-muted-foreground mb-1">Drop files here or click to upload</p>
              <p className="text-xs text-muted-foreground">PDF, DOCX, TXT up to 10MB</p>
            </div>

            {/* Document List */}
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Recent Documents</h4>
              
              {documents.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <FileText className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p className="text-sm">No documents uploaded yet</p>
                  <p className="text-xs mt-1">Upload your first document to get started</p>
                </div>
              ) : (
                documents.map((document) => (
                  <div key={document.id} className="bg-secondary rounded-lg p-3 space-y-2">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start space-x-2 min-w-0 flex-1">
                        <FileText className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-medium truncate" title={document.originalName}>
                            {document.originalName}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {formatFileSize(document.size)}
                            {document.pageCount && ` • ${document.pageCount} pages`}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-1">
                        <div
                          className={`w-2 h-2 rounded-full ${getStatusColor(document.status)}`}
                          title={getStatusText(document.status)}
                        />
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="p-1 h-6 w-6 text-muted-foreground hover:text-foreground"
                              data-testid={`dropdown-document-${document.id}`}
                            >
                              <MoreHorizontal className="w-3 h-3" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem
                              onClick={() => deleteDocumentMutation.mutate(document.id)}
                              disabled={deleteDocumentMutation.isPending}
                              className="text-destructive focus:text-destructive"
                              data-testid={`button-delete-${document.id}`}
                            >
                              <Trash2 className="w-4 h-4 mr-2" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-muted-foreground">
                        {document.status === "processing" 
                          ? "Processing embeddings..." 
                          : `Embeddings: ${document.embeddingCount.toLocaleString()}`}
                      </span>
                      <span className={`${
                        document.status === "ready" ? "text-green-400" :
                        document.status === "processing" ? "text-yellow-400" :
                        document.status === "error" ? "text-red-400" : "text-muted-foreground"
                      }`}>
                        {getStatusText(document.status)}
                      </span>
                    </div>
                    {document.status === "processing" && (
                      <div className="w-full bg-muted rounded-full h-1">
                        <div className="bg-yellow-500 h-1 rounded-full animate-pulse" style={{ width: "67%" }} />
                      </div>
                    )}
                    {document.processingError && (
                      <div className="text-xs text-red-400 bg-red-500/10 p-2 rounded">
                        {document.processingError}
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>

            {/* Document Stats */}
            <div className="bg-muted rounded-lg p-3">
              <h4 className="text-sm font-medium mb-2">Storage Overview</h4>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Total Documents:</span>
                  <span className="font-mono" data-testid="stat-total-documents">
                    {totalDocuments}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Vector Embeddings:</span>
                  <span className="font-mono" data-testid="stat-total-embeddings">
                    {totalEmbeddings.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Storage Used:</span>
                  <span className="font-mono" data-testid="stat-storage-used">
                    {formatFileSize(totalSize)}
                  </span>
                </div>
                <div className="w-full bg-background rounded-full h-1.5 mt-2">
                  <div 
                    className="bg-primary h-1.5 rounded-full transition-all duration-500" 
                    style={{ width: `${storagePercentage}%` }}
                  />
                </div>
                <div className="text-right text-muted-foreground">
                  <span data-testid="stat-storage-percentage">
                    {storagePercentage.toFixed(1)}% of {formatFileSize(storageLimit)}
                  </span>
                </div>
              </div>
            </div>
          </>
        )}

        {activeTab === "context" && (
          <div className="text-center py-8 text-muted-foreground">
            <p className="text-sm">Context panel coming soon</p>
            <p className="text-xs mt-1">View document context used in conversations</p>
          </div>
        )}

        {activeTab === "memory" && (
          <div className="text-center py-8 text-muted-foreground">
            <p className="text-sm">Memory panel coming soon</p>
            <p className="text-xs mt-1">Manage agent memory and conversation history</p>
          </div>
        )}
      </div>
    </div>
  );
}
