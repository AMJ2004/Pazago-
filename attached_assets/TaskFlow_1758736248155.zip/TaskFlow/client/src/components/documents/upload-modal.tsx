import { useState, useCallback } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useDropzone } from "react-dropzone";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { CloudUpload, X, FileText, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { documentsApi } from "@/lib/api";

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface UploadingFile {
  file: File;
  progress: number;
  status: "uploading" | "success" | "error";
  error?: string;
  id?: string;
}

export function UploadModal({ isOpen, onClose }: UploadModalProps) {
  const [uploadingFiles, setUploadingFiles] = useState<UploadingFile[]>([]);
  const [processingOptions, setProcessingOptions] = useState({
    extractText: true,
    generateEmbeddings: true,
    ocrImages: false,
    extractMetadata: false,
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const uploadMutation = useMutation({
    mutationFn: documentsApi.uploadDocument,
    onSuccess: (data, variables) => {
      setUploadingFiles(prev =>
        prev.map(f =>
          f.file === variables
            ? { ...f, progress: 100, status: "success", id: data.id }
            : f
        )
      );
      queryClient.invalidateQueries({ queryKey: ["/api/documents"] });
      toast({
        title: "Document uploaded successfully",
        description: `${variables.name} is being processed.`,
      });
    },
    onError: (error: Error, variables) => {
      setUploadingFiles(prev =>
        prev.map(f =>
          f.file === variables
            ? { ...f, status: "error", error: error.message }
            : f
        )
      );
      toast({
        title: "Upload failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const newFiles = acceptedFiles.map(file => ({
      file,
      progress: 0,
      status: "uploading" as const,
    }));
    
    setUploadingFiles(prev => [...prev, ...newFiles]);

    // Upload each file
    acceptedFiles.forEach(file => {
      uploadMutation.mutate(file);
    });
  }, [uploadMutation]);

  const { getRootProps, getInputProps, isDragActive, fileRejections } = useDropzone({
    onDrop,
    accept: {
      "application/pdf": [".pdf"],
      "text/plain": [".txt"],
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [".docx"],
    },
    maxSize: 10 * 1024 * 1024, // 10MB
    multiple: true,
  });

  const handleClose = () => {
    if (uploadingFiles.some(f => f.status === "uploading")) {
      toast({
        title: "Upload in progress",
        description: "Please wait for uploads to complete before closing.",
        variant: "destructive",
      });
      return;
    }
    setUploadingFiles([]);
    onClose();
  };

  const removeFile = (file: File) => {
    setUploadingFiles(prev => prev.filter(f => f.file !== file));
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 B";
    const k = 1024;
    const sizes = ["B", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            Upload Documents
            <Button
              variant="ghost"
              size="icon"
              onClick={handleClose}
              data-testid="button-close-upload-modal"
            >
              <X className="w-5 h-5" />
            </Button>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Upload Area */}
          <div
            {...getRootProps()}
            className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
              isDragActive
                ? "border-primary bg-primary/10"
                : "border-border hover:border-primary/50"
            }`}
            data-testid="upload-dropzone"
          >
            <input {...getInputProps()} />
            <CloudUpload className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <h4 className="text-lg font-medium mb-2">
              {isDragActive ? "Drop files here..." : "Drop your files here"}
            </h4>
            <p className="text-muted-foreground mb-4">
              Support for PDF, DOCX, TXT files up to 10MB each
            </p>
            <Button variant="outline" data-testid="button-browse-files">
              Browse Files
            </Button>
          </div>

          {/* File Rejections */}
          {fileRejections.length > 0 && (
            <div className="space-y-2">
              {fileRejections.map(({ file, errors }) => (
                <div key={file.name} className="flex items-center space-x-2 text-sm text-red-400 bg-red-500/10 p-2 rounded">
                  <AlertCircle className="w-4 h-4" />
                  <span>{file.name}: {errors[0]?.message}</span>
                </div>
              ))}
            </div>
          )}

          {/* Uploading Files */}
          {uploadingFiles.length > 0 && (
            <div className="space-y-3">
              <h4 className="font-medium">Uploading Files</h4>
              {uploadingFiles.map(({ file, progress, status, error }) => (
                <div key={file.name} className="border border-border rounded-lg p-3">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <FileText className="w-4 h-4" />
                      <span className="text-sm font-medium">{file.name}</span>
                      <span className="text-xs text-muted-foreground">
                        ({formatFileSize(file.size)})
                      </span>
                    </div>
                    {status === "uploading" && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeFile(file)}
                        data-testid={`button-remove-${file.name}`}
                      >
                        <X className="w-3 h-3" />
                      </Button>
                    )}
                  </div>
                  
                  {status === "uploading" && (
                    <Progress value={progress} className="mb-2" />
                  )}
                  
                  <div className="flex items-center justify-between text-xs">
                    <span className={`${
                      status === "success" ? "text-green-400" :
                      status === "error" ? "text-red-400" : "text-muted-foreground"
                    }`}>
                      {status === "success" ? "Upload complete - Processing..." :
                       status === "error" ? `Error: ${error}` :
                       "Uploading..."}
                    </span>
                    {status === "uploading" && <span>{progress}%</span>}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Processing Options */}
          <div className="space-y-4">
            <h4 className="font-medium">Processing Options</h4>
            <div className="grid grid-cols-2 gap-4">
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={processingOptions.extractText}
                  onChange={(e) => setProcessingOptions(prev => ({ ...prev, extractText: e.target.checked }))}
                  className="rounded"
                />
                <span className="text-sm">Extract text content</span>
              </label>
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={processingOptions.generateEmbeddings}
                  onChange={(e) => setProcessingOptions(prev => ({ ...prev, generateEmbeddings: e.target.checked }))}
                  className="rounded"
                />
                <span className="text-sm">Generate embeddings</span>
              </label>
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={processingOptions.ocrImages}
                  onChange={(e) => setProcessingOptions(prev => ({ ...prev, ocrImages: e.target.checked }))}
                  className="rounded"
                />
                <span className="text-sm">OCR for images</span>
              </label>
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={processingOptions.extractMetadata}
                  onChange={(e) => setProcessingOptions(prev => ({ ...prev, extractMetadata: e.target.checked }))}
                  className="rounded"
                />
                <span className="text-sm">Extract metadata</span>
              </label>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end space-x-3">
            <Button
              variant="outline"
              onClick={handleClose}
              disabled={uploadingFiles.some(f => f.status === "uploading")}
              data-testid="button-cancel-upload"
            >
              {uploadingFiles.some(f => f.status === "uploading") ? "Uploading..." : "Done"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
