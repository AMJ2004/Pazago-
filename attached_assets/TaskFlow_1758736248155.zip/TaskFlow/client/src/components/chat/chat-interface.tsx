import { useState, useRef, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Bot, User, Send, Loader2 } from "lucide-react";
import { chatApi } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  createdAt: string;
  metadata?: string;
}

export function ChatInterface() {
  const [message, setMessage] = useState("");
  const [conversationId, setConversationId] = useState<string>();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: messages = [] } = useQuery({
    queryKey: ["/api/conversations", conversationId, "messages"],
    queryFn: () => conversationId ? chatApi.getConversationMessages(conversationId) : Promise.resolve([]),
    enabled: !!conversationId,
  });

  const sendMessageMutation = useMutation({
    mutationFn: ({ message, conversationId }: { message: string; conversationId?: string }) =>
      chatApi.sendMessage(message, conversationId),
    onSuccess: (data) => {
      setConversationId(data.conversationId);
      queryClient.invalidateQueries({ 
        queryKey: ["/api/conversations", data.conversationId, "messages"] 
      });
      queryClient.invalidateQueries({ 
        queryKey: ["/api/conversations"] 
      });
      setMessage("");
      
      if (data.context?.documentsUsed) {
        toast({
          title: "Used Document Context",
          description: `Referenced ${data.context.documentsUsed.length} documents and ${data.context.chunksUsed} text chunks`,
        });
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to send message",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim() && !sendMessageMutation.isPending) {
      sendMessageMutation.mutate({ message: message.trim(), conversationId });
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, sendMessageMutation.isPending]);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
      textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 120) + "px";
    }
  }, [message]);

  return (
    <div className="flex-1 flex flex-col">
      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6" data-testid="chat-messages">
        {messages.length === 0 && (
          <div className="flex space-x-3">
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
              <Bot className="w-4 h-4 text-primary-foreground" />
            </div>
            <div className="flex-1 space-y-2">
              <div className="chat-bubble-ai rounded-lg p-4 max-w-3xl">
                <p className="text-sm leading-relaxed">
                  Hello! I'm your RAG Agent, ready to help you with document analysis and questions. 
                  I can process PDFs, create embeddings, and provide intelligent responses based on your uploaded documents.
                </p>
              </div>
              <div className="text-xs text-muted-foreground flex items-center space-x-2">
                <span>Agent</span>
                <span>•</span>
                <span>Just now</span>
              </div>
            </div>
          </div>
        )}

        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex space-x-3 ${msg.role === "user" ? "justify-end" : ""}`}
            data-testid={`message-${msg.role}`}
          >
            {msg.role === "assistant" && (
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
                <Bot className="w-4 h-4 text-primary-foreground" />
              </div>
            )}
            
            <div className={`flex-1 space-y-2 ${msg.role === "user" ? "flex flex-col items-end" : ""}`}>
              <div
                className={`rounded-lg p-4 max-w-3xl ${
                  msg.role === "user"
                    ? "chat-bubble-user text-white"
                    : "chat-bubble-ai"
                }`}
              >
                <p className="text-sm leading-relaxed whitespace-pre-wrap">
                  {msg.content}
                </p>
              </div>
              <div className="text-xs text-muted-foreground flex items-center space-x-2">
                {msg.role === "user" ? (
                  <>
                    <span>{new Date(msg.createdAt).toLocaleTimeString()}</span>
                    <span>•</span>
                    <span>You</span>
                  </>
                ) : (
                  <>
                    <span>Agent</span>
                    <span>•</span>
                    <span>{new Date(msg.createdAt).toLocaleTimeString()}</span>
                  </>
                )}
              </div>
            </div>

            {msg.role === "user" && (
              <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center flex-shrink-0">
                <User className="w-4 h-4 text-secondary-foreground" />
              </div>
            )}
          </div>
        ))}

        {sendMessageMutation.isPending && (
          <div className="flex space-x-3">
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
              <Bot className="w-4 h-4 text-primary-foreground" />
            </div>
            <div className="flex-1 space-y-2">
              <div className="chat-bubble-ai rounded-lg p-4 max-w-3xl">
                <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Analyzing documents and generating response...</span>
                </div>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Chat Input */}
      <div className="border-t border-border p-4">
        <form onSubmit={handleSubmit} className="flex space-x-3">
          <div className="flex-1 relative">
            <Textarea
              ref={textareaRef}
              placeholder="Ask about your documents..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyDown={handleKeyDown}
              className="min-h-[44px] max-h-[120px] bg-input border border-border rounded-lg px-4 py-3 pr-12 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring resize-none"
              disabled={sendMessageMutation.isPending}
              data-testid="input-chat-message"
            />
            <Button
              type="submit"
              size="sm"
              className="absolute right-3 top-3 p-1 h-6 w-6"
              disabled={!message.trim() || sendMessageMutation.isPending}
              data-testid="button-send-message"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </form>
        <div className="flex items-center justify-between mt-2 text-xs text-muted-foreground">
          <span>Press Shift+Enter for new line</span>
          <span>Ready to chat with your documents</span>
        </div>
      </div>
    </div>
  );
}
