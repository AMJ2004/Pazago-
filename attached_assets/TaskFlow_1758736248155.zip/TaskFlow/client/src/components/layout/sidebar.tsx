import { Bot, MessageSquare, Folder, Database, Brain, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { Document } from "@/lib/api";

interface SidebarProps {
  documents: Document[];
  health?: {
    status: string;
    openai: boolean;
    database: boolean;
  };
}

export function Sidebar({ documents, health }: SidebarProps) {
  const embeddingCount = documents.reduce((acc, doc) => acc + doc.embeddingCount, 0);
  const readyDocuments = documents.filter(doc => doc.status === "ready").length;

  return (
    <div className="w-64 bg-card border-r border-border flex flex-col">
      {/* Logo & Brand */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <Bot className="w-5 h-5 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-lg font-semibold gradient-text">RAG Agent</h1>
            <p className="text-xs text-muted-foreground">Document AI Assistant</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2">
        <Button
          variant="secondary"
          className="w-full justify-start bg-accent text-accent-foreground hover:bg-accent/80"
          data-testid="nav-chat"
        >
          <MessageSquare className="w-4 h-4 mr-3" />
          <span className="text-sm font-medium">Chat</span>
        </Button>
        
        <Button
          variant="ghost"
          className="w-full justify-start text-muted-foreground hover:bg-accent hover:text-accent-foreground"
          data-testid="nav-documents"
        >
          <Folder className="w-4 h-4 mr-3" />
          <span className="text-sm font-medium">Documents</span>
          <span className="ml-auto text-xs bg-muted px-2 py-0.5 rounded-full">
            {documents.length}
          </span>
        </Button>
        
        <Button
          variant="ghost"
          className="w-full justify-start text-muted-foreground hover:bg-accent hover:text-accent-foreground"
          data-testid="nav-vector-store"
        >
          <Database className="w-4 h-4 mr-3" />
          <span className="text-sm font-medium">Vector Store</span>
        </Button>
        
        <Button
          variant="ghost"
          className="w-full justify-start text-muted-foreground hover:bg-accent hover:text-accent-foreground"
          data-testid="nav-agent-memory"
        >
          <Brain className="w-4 h-4 mr-3" />
          <span className="text-sm font-medium">Agent Memory</span>
        </Button>
        
        <Button
          variant="ghost"
          className="w-full justify-start text-muted-foreground hover:bg-accent hover:text-accent-foreground"
          data-testid="nav-settings"
        >
          <Settings className="w-4 h-4 mr-3" />
          <span className="text-sm font-medium">Settings</span>
        </Button>
      </nav>

      {/* Status */}
      <div className="p-4 border-t border-border">
        <div className="bg-secondary rounded-lg p-3 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">Vector DB</span>
            <div className="flex items-center space-x-1">
              <div 
                className={`w-2 h-2 rounded-full ${
                  health?.database ? "bg-green-500 animate-pulse-soft" : "bg-red-500"
                }`}
              />
              <span className={`text-xs ${health?.database ? "text-green-400" : "text-red-400"}`}>
                {health?.database ? "Online" : "Offline"}
              </span>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">Embeddings</span>
            <span className="text-xs font-mono" data-testid="text-embedding-count">
              {embeddingCount.toLocaleString()}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">Ready Docs</span>
            <span className="text-xs font-mono" data-testid="text-ready-docs">
              {readyDocuments}/{documents.length}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
