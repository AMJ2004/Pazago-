import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Sidebar } from "@/components/layout/sidebar";
import { ChatInterface } from "@/components/chat/chat-interface";
import { DocumentPanel } from "@/components/documents/document-panel";
import { UploadModal } from "@/components/documents/upload-modal";
import { Button } from "@/components/ui/button";
import { Upload, HelpCircle } from "lucide-react";
import { documentsApi, healthApi } from "@/lib/api";

export default function Dashboard() {
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<"documents" | "context" | "memory">("documents");

  const { data: documents = [] } = useQuery({
    queryKey: ["/api/documents"],
    queryFn: () => documentsApi.getDocuments(),
  });

  const { data: health } = useQuery({
    queryKey: ["/api/health"],
    queryFn: () => healthApi.checkHealth(),
    refetchInterval: 30000, // Check health every 30 seconds
  });

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar documents={documents} health={health} />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-card border-b border-border px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h2 className="text-xl font-semibold">Document Processing & Chat</h2>
            <div className="text-sm text-muted-foreground">
              Last updated: <span>Just now</span>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <Button
              onClick={() => setIsUploadModalOpen(true)}
              className="bg-primary text-primary-foreground hover:bg-primary/90"
              data-testid="button-upload-document"
            >
              <Upload className="w-4 h-4 mr-2" />
              Upload Document
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="text-muted-foreground hover:text-foreground"
              data-testid="button-help"
            >
              <HelpCircle className="w-5 h-5" />
            </Button>
          </div>
        </header>

        {/* Main Content Area */}
        <div className="flex-1 overflow-hidden flex">
          <ChatInterface />
          <DocumentPanel 
            activeTab={activeTab}
            onTabChange={setActiveTab}
            documents={documents}
          />
        </div>
      </div>

      <UploadModal 
        isOpen={isUploadModalOpen}
        onClose={() => setIsUploadModalOpen(false)}
      />
    </div>
  );
}
