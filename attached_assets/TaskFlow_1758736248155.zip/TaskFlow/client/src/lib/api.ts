import { apiRequest } from "./queryClient";

export interface Document {
  id: string;
  filename: string;
  originalName: string;
  mimeType: string;
  size: number;
  status: "uploading" | "processing" | "ready" | "error";
  pageCount?: number;
  embeddingCount: number;
  createdAt: string;
  processingError?: string;
}

export interface Message {
  id: string;
  conversationId: string;
  role: "user" | "assistant" | "system";
  content: string;
  metadata?: string;
  createdAt: string;
}

export interface Conversation {
  id: string;
  userId: string;
  title?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ChatResponse {
  message: Message;
  conversationId: string;
  context?: {
    documentsUsed: Array<{ id: string; name: string }>;
    chunksUsed: number;
  };
}

export const documentsApi = {
  async uploadDocument(file: File): Promise<Document> {
    const formData = new FormData();
    formData.append("file", file);
    
    const response = await fetch("/api/documents/upload", {
      method: "POST",
      body: formData,
      credentials: "include",
    });
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || "Upload failed");
    }
    
    return response.json();
  },

  async getDocuments(): Promise<Document[]> {
    const response = await apiRequest("GET", "/api/documents");
    return response.json();
  },

  async getDocument(id: string): Promise<Document> {
    const response = await apiRequest("GET", `/api/documents/${id}`);
    return response.json();
  },

  async deleteDocument(id: string): Promise<void> {
    await apiRequest("DELETE", `/api/documents/${id}`);
  },

  async searchDocuments(query: string, limit = 5): Promise<{ chunks: any[]; documents: Document[] }> {
    const response = await apiRequest("GET", `/api/search?q=${encodeURIComponent(query)}&limit=${limit}`);
    return response.json();
  },
};

export const chatApi = {
  async sendMessage(message: string, conversationId?: string): Promise<ChatResponse> {
    const response = await apiRequest("POST", "/api/chat", { message, conversationId });
    return response.json();
  },

  async getConversations(): Promise<Conversation[]> {
    const response = await apiRequest("GET", "/api/conversations");
    return response.json();
  },

  async getConversationMessages(conversationId: string): Promise<Message[]> {
    const response = await apiRequest("GET", `/api/conversations/${conversationId}/messages`);
    return response.json();
  },
};

export const healthApi = {
  async checkHealth(): Promise<{ status: string; openai: boolean; database: boolean }> {
    const response = await apiRequest("GET", "/api/health");
    return response.json();
  },
};
